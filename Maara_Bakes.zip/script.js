/* =====================================================
   MAARA BAKES & SWEETS — script.js (Enhanced v2)
   Features: loader, cursor glow, particles, parallax,
   counter animation, menu filter, gallery lightbox,
   reviews carousel, cart, form validation, confetti
   ===================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* ──────────────────────────────────────────────────
     1. PAGE LOADER
  ────────────────────────────────────────────────── */
  const loader = document.getElementById('loader');
  window.addEventListener('load', () => {
    setTimeout(() => {
      loader.classList.add('gone');
      // Trigger hero animations after load
      document.querySelectorAll('.reveal-hero').forEach((el, i) => {
        setTimeout(() => el.classList.add('vis'), 100 + i * 100);
      });
    }, 1800);
  });


  /* ──────────────────────────────────────────────────
     2. CURSOR GLOW
  ────────────────────────────────────────────────── */
  const cursorGlow = document.getElementById('cursorGlow');
  if (window.innerWidth > 768) {
    document.addEventListener('mousemove', (e) => {
      cursorGlow.style.left = e.clientX + 'px';
      cursorGlow.style.top  = e.clientY + 'px';
    });
  }


  /* ──────────────────────────────────────────────────
     3. FLOATING PARTICLES (hero)
  ────────────────────────────────────────────────── */
  const particleContainer = document.getElementById('particles');
  const PARTICLE_COUNT = 18;
  const colors = ['rgba(201,149,42,.5)', 'rgba(232,160,170,.5)', 'rgba(255,255,255,.35)', 'rgba(253,248,239,.4)'];

  for (let i = 0; i < PARTICLE_COUNT; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const size = Math.random() * 6 + 3;
    const left = Math.random() * 100;
    const delay = Math.random() * 12;
    const dur   = 8 + Math.random() * 8;
    const color = colors[Math.floor(Math.random() * colors.length)];
    p.style.cssText = `
      width:${size}px;height:${size}px;
      left:${left}%;
      background:${color};
      animation-duration:${dur}s;
      animation-delay:${delay}s;
    `;
    particleContainer.appendChild(p);
  }


  /* ──────────────────────────────────────────────────
     4. NAVBAR — scroll + mobile toggle
  ────────────────────────────────────────────────── */
  const navbar    = document.getElementById('navbar');
  const navToggle = document.getElementById('navToggle');
  const navLinks  = document.getElementById('navLinks');
  const allLinks  = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 70);
    updateActiveLink();
    handleBackToTop();
  });

  navToggle.addEventListener('click', () => {
    navToggle.classList.toggle('open');
    navLinks.classList.toggle('open');
  });
  allLinks.forEach(l => l.addEventListener('click', () => {
    navToggle.classList.remove('open');
    navLinks.classList.remove('open');
  }));

  function updateActiveLink() {
    const sections = document.querySelectorAll('section[id]');
    let current = '';
    sections.forEach(s => {
      if (window.scrollY >= s.offsetTop - 120) current = s.id;
    });
    allLinks.forEach(l => {
      l.classList.toggle('active', l.getAttribute('href') === `#${current}`);
    });
  }


  /* ──────────────────────────────────────────────────
     5. PARALLAX HERO BACKGROUND
  ────────────────────────────────────────────────── */
  const heroBgImg = document.getElementById('heroBgImg');
  if (heroBgImg) {
    window.addEventListener('scroll', () => {
      const y = window.scrollY;
      heroBgImg.style.transform = `translateY(${y * 0.25}px)`;
    });
  }


  /* ──────────────────────────────────────────────────
     6. SCROLL REVEAL (IntersectionObserver)
  ────────────────────────────────────────────────── */
  const revealEls = document.querySelectorAll('.reveal-up, .reveal-left, .reveal-right');
  const revealObs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('vis');
        revealObs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.13 });
  revealEls.forEach(el => revealObs.observe(el));


  /* ──────────────────────────────────────────────────
     7. COUNTER ANIMATION (hero stats)
  ────────────────────────────────────────────────── */
  const counters = document.querySelectorAll('.stat-num[data-target]');
  let countersStarted = false;

  function startCounters() {
    if (countersStarted) return;
    countersStarted = true;
    counters.forEach(counter => {
      const target = parseInt(counter.dataset.target);
      const duration = 1800;
      const step = target / (duration / 16);
      let current = 0;
      const tick = () => {
        current = Math.min(current + step, target);
        counter.textContent = Math.floor(current);
        if (current < target) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
  }

  // Start counters when hero is visible
  const heroObs = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting) { startCounters(); heroObs.disconnect(); }
  }, { threshold: 0.3 });
  const heroSection = document.getElementById('home');
  if (heroSection) heroObs.observe(heroSection);


  /* ──────────────────────────────────────────────────
     8. MENU FILTER TABS
  ────────────────────────────────────────────────── */
  const tabBtns   = document.querySelectorAll('.tab-btn');
  const menuCards = document.querySelectorAll('.menu-card');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.dataset.category;
      menuCards.forEach((card, i) => {
        const show = cat === 'all' || card.dataset.category === cat;
        card.classList.toggle('hidden', !show);
        if (show) {
          card.style.animationDelay = `${(i % 4) * 0.06}s`;
          // Re-trigger reveal
          card.classList.remove('vis');
          setTimeout(() => card.classList.add('vis'), 30);
        }
      });
    });
  });


  /* ──────────────────────────────────────────────────
     9. GALLERY LIGHTBOX
  ────────────────────────────────────────────────── */
  const galItems   = document.querySelectorAll('.gal-item');
  const lightbox   = document.getElementById('lightbox');
  const lbImg      = document.getElementById('lbImg');
  const lbCaption  = document.getElementById('lbCaption');
  const lbClose    = document.getElementById('lbClose');
  const lbPrev     = document.getElementById('lbPrev');
  const lbNext     = document.getElementById('lbNext');
  const lbBackdrop = document.getElementById('lbBackdrop');
  let currentGalIdx = 0;
  const galData = Array.from(galItems).map(item => ({
    src:     item.dataset.src,
    caption: item.dataset.caption,
  }));

  function openLightbox(idx) {
    currentGalIdx = idx;
    lbImg.src = galData[idx].src;
    lbCaption.textContent = galData[idx].caption;
    lightbox.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeLightbox() {
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
  }
  function lbNavigate(dir) {
    currentGalIdx = (currentGalIdx + dir + galData.length) % galData.length;
    lbImg.style.opacity = '0';
    setTimeout(() => {
      lbImg.src = galData[currentGalIdx].src;
      lbCaption.textContent = galData[currentGalIdx].caption;
      lbImg.style.opacity = '1';
    }, 200);
  }

  galItems.forEach((item, i) => item.addEventListener('click', () => openLightbox(i)));
  lbClose.addEventListener('click', closeLightbox);
  lbBackdrop.addEventListener('click', closeLightbox);
  lbPrev.addEventListener('click', () => lbNavigate(-1));
  lbNext.addEventListener('click', () => lbNavigate(1));
  document.addEventListener('keydown', (e) => {
    if (!lightbox.classList.contains('open')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft')  lbNavigate(-1);
    if (e.key === 'ArrowRight') lbNavigate(1);
  });
  lbImg.style.transition = 'opacity .2s ease';


  /* ──────────────────────────────────────────────────
     10. REVIEWS CAROUSEL
  ────────────────────────────────────────────────── */
  const reviewsTrack = document.getElementById('reviewsTrack');
  const revPrev      = document.getElementById('reviewPrev');
  const revNext      = document.getElementById('reviewNext');
  const revDotsEl    = document.getElementById('reviewDots');
  const reviewCards  = reviewsTrack.querySelectorAll('.review-card');
  const totalRevs    = reviewCards.length;
  let revIdx         = 0;

  // Build dots
  for (let i = 0; i < totalRevs; i++) {
    const d = document.createElement('div');
    d.className = `rev-dot${i === 0 ? ' active' : ''}`;
    d.addEventListener('click', () => goRev(i));
    revDotsEl.appendChild(d);
  }

  function goRev(idx) {
    revIdx = idx;
    reviewsTrack.style.transform = `translateX(-${idx * 100}%)`;
    revDotsEl.querySelectorAll('.rev-dot').forEach((d, i) => d.classList.toggle('active', i === idx));
  }

  revNext.addEventListener('click', () => goRev((revIdx + 1) % totalRevs));
  revPrev.addEventListener('click', () => goRev((revIdx - 1 + totalRevs) % totalRevs));

  // Touch swipe
  let revTouchX = 0;
  reviewsTrack.addEventListener('touchstart', e => { revTouchX = e.changedTouches[0].clientX; });
  reviewsTrack.addEventListener('touchend',   e => {
    const diff = revTouchX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 40) goRev(diff > 0 ? (revIdx + 1) % totalRevs : (revIdx - 1 + totalRevs) % totalRevs);
  });

  // Auto-rotate
  let revTimer = setInterval(() => goRev((revIdx + 1) % totalRevs), 5000);
  reviewsTrack.addEventListener('mouseenter', () => clearInterval(revTimer));
  reviewsTrack.addEventListener('mouseleave', () => {
    revTimer = setInterval(() => goRev((revIdx + 1) % totalRevs), 5000);
  });


  /* ──────────────────────────────────────────────────
     11. CART — add items from menu
  ────────────────────────────────────────────────── */
  const cartItemsEl = document.getElementById('cartItems');
  const cartTotalEl = document.getElementById('cartTotal');
  const totalAmtEl  = document.getElementById('totalAmt');
  const itemInput   = document.getElementById('item');
  const cart        = {};

  window.addToOrder = function(name, price, btnEl) {
    cart[name] = cart[name] ? { price, qty: cart[name].qty + 1 } : { price, qty: 1 };
    renderCart();

    // Button feedback
    const orig = btnEl.innerHTML;
    btnEl.classList.add('added');
    btnEl.innerHTML = '<i class="fa fa-check"></i> Added!';
    setTimeout(() => {
      btnEl.classList.remove('added');
      btnEl.innerHTML = orig;
    }, 1400);
  };

  function renderCart() {
    const keys = Object.keys(cart);
    if (!keys.length) {
      cartItemsEl.innerHTML = '<p class="cart-empty">No items added yet — browse the menu above!</p>';
      cartTotalEl.style.display = 'none';
      return;
    }
    let html = '', total = 0;
    keys.forEach(name => {
      const { price, qty } = cart[name];
      const sub = price * qty;
      total += sub;
      html += `<div class="cart-item"><span class="cart-item-name">${name} × ${qty}</span><span class="cart-item-price">₹${sub}</span></div>`;
    });
    cartItemsEl.innerHTML = html;
    totalAmtEl.textContent = total;
    cartTotalEl.style.display = 'block';

    if (itemInput && !itemInput.dataset.edited) {
      itemInput.value = keys.join(', ');
    }
  }
  if (itemInput) itemInput.addEventListener('input', () => { itemInput.dataset.edited = '1'; });


  /* ──────────────────────────────────────────────────
     12. FORM VALIDATION & SUBMISSION
  ────────────────────────────────────────────────── */
  const orderForm = document.getElementById('orderForm');

  orderForm.addEventListener('submit', e => {
    e.preventDefault();
    if (validateForm()) {
      showPopup();
      orderForm.reset();
      if (itemInput) delete itemInput.dataset.edited;
    }
  });

  function validateForm() {
    let ok = true;
    const name  = document.getElementById('name');
    const phone = document.getElementById('phone');
    const item  = document.getElementById('item');
    const date  = document.getElementById('date');

    ok = checkField(name,  document.getElementById('nameError'),
      !name.value.trim() || name.value.trim().length < 2,
      'Please enter your full name.') && ok;

    const cp = phone.value.replace(/[\s\-+]/g,'');
    ok = checkField(phone, document.getElementById('phoneError'),
      !/^[6-9]\d{9}$/.test(cp),
      'Enter a valid 10-digit Indian mobile number.') && ok;

    ok = checkField(item,  document.getElementById('itemError'),
      !item.value.trim(),
      'Please tell us what you\'d like to order.') && ok;

    const today = new Date(); today.setHours(0,0,0,0);
    ok = checkField(date,  document.getElementById('dateError'),
      !date.value || new Date(date.value) < today,
      'Please select a valid future date.') && ok;

    return ok;
  }

  function checkField(input, errEl, isInvalid, msg) {
    input.classList.toggle('error', isInvalid);
    errEl.textContent = isInvalid ? msg : '';
    return !isInvalid;
  }

  ['name','phone','item','date'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('blur', validateForm);
  });

  // Set min date
  const dateInput = document.getElementById('date');
  if (dateInput) {
    const t = new Date();
    dateInput.min = `${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,'0')}-${String(t.getDate()).padStart(2,'0')}`;
  }


  /* ──────────────────────────────────────────────────
     13. ORDER POPUP + CONFETTI
  ────────────────────────────────────────────────── */
  const popupOverlay = document.getElementById('popupOverlay');

  function showPopup() {
    popupOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    launchConfetti();
  }
  window.closePopup = function() {
    popupOverlay.classList.remove('active');
    document.body.style.overflow = '';
  };
  popupOverlay.addEventListener('click', e => { if (e.target === popupOverlay) window.closePopup(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') window.closePopup(); });

  function launchConfetti() {
    const container = document.getElementById('confettiContainer');
    container.innerHTML = '';
    const colors = ['#C9952A','#E8A0AA','#FFFFFF','#3E1F0D','#C96070','#4A7A50'];
    for (let i = 0; i < 60; i++) {
      const c = document.createElement('div');
      c.className = 'confetti-piece';
      c.style.cssText = `
        left:${Math.random()*100}%;
        background:${colors[Math.floor(Math.random()*colors.length)]};
        animation-duration:${1.5+Math.random()*2}s;
        animation-delay:${Math.random()*.8}s;
        transform:rotate(${Math.random()*360}deg);
        border-radius:${Math.random() > .5 ? '50%' : '2px'};
        width:${5+Math.random()*8}px;
        height:${5+Math.random()*8}px;
      `;
      container.appendChild(c);
    }
  }


  /* ──────────────────────────────────────────────────
     14. BACK TO TOP
  ────────────────────────────────────────────────── */
  const backToTop = document.getElementById('backToTop');
  function handleBackToTop() {
    backToTop.classList.toggle('visible', window.scrollY > 450);
  }
  backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));


  /* ──────────────────────────────────────────────────
     15. SMOOTH SCROLL
  ────────────────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        const top = target.getBoundingClientRect().top + window.pageYOffset - 76;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });


  /* ──────────────────────────────────────────────────
     16. NEWSLETTER FORM
  ────────────────────────────────────────────────── */
  const nlBtn   = document.getElementById('nlBtn');
  const nlEmail = document.getElementById('nlEmail');
  if (nlBtn && nlEmail) {
    nlBtn.addEventListener('click', () => {
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (re.test(nlEmail.value)) {
        nlEmail.value = '✓ You\'re subscribed!';
        nlEmail.style.color = '#90C890';
        setTimeout(() => { nlEmail.value = ''; nlEmail.style.color = ''; }, 3200);
      } else {
        nlEmail.style.borderColor = 'var(--pink)';
        nlEmail.placeholder = 'Enter a valid email!';
        setTimeout(() => { nlEmail.style.borderColor = ''; nlEmail.placeholder = 'Your email address'; }, 2400);
      }
    });
  }


  /* ──────────────────────────────────────────────────
     17. CARD TILT EFFECT (3D hover)
  ────────────────────────────────────────────────── */
  if (window.innerWidth > 768) {
    document.querySelectorAll('.menu-card').forEach(card => {
      card.addEventListener('mousemove', (e) => {
        const rect  = card.getBoundingClientRect();
        const cx    = rect.left + rect.width  / 2;
        const cy    = rect.top  + rect.height / 2;
        const dx    = (e.clientX - cx) / (rect.width  / 2);
        const dy    = (e.clientY - cy) / (rect.height / 2);
        card.style.transform = `translateY(-10px) scale(1.01) rotateX(${-dy*4}deg) rotateY(${dx*4}deg)`;
      });
      card.addEventListener('mouseleave', () => {
        card.style.transform = '';
      });
    });
  }

  // Init
  updateActiveLink();

}); // END DOMContentLoaded
